<!DOCTYPE html>
<html>
    <title>News Portal Website</title>
    <head></head>
    <body style="margin:0">
<!-- Start Header -->
        
        <table border ="0" width = "100%" cellpadding ="0" cellspacing="0" bgcolor="">
            <tr>
                <td>
                    <table border="0" width ="100%"  cellpadding="0" cellspacing ="0" align="center" bgcolor="#FFFFFF">
                        <!-- <td><img src="" style="width:70%;height:20%"></td> -->
                        <td align="center"style="font-family: Arial"><h1><strong>News Portal System</strong></h1></td>
                        <!--<td align="right"style="font-family: Arial, Helvetica, sans-serif;"><strong>Login</strong> OR <strong>Rgister</strong> </td>-->
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table border="1" width="100%" cellpadding="15" cellspacing ="1" align="center" bgcolor="#247CC6">
                        <td>
                            <a href="Admin/Asignin.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Admin
                                </font>
                            </a>
                        </td>
                        <td>
                            <a href="User/Usignin.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    User
                                </font>
                            </a>
                        </td>
                        <td>
                            <a href="ContentWriter/Csignin.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Content Writer
                                </font>
                                
                            </a>
                        </td>
                        <td>
                            <a href="Publisher/Psignin.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Publisher
                                </font>
                            </a>
                        </td>
                        
                    </td>
                    </table>
                </td>
            </tr>
        </table>
<!-- End Header -->

<!-- Start Home -->
<table border ="0" width = "100%" height="500px" cellpadding ="0" cellspacing="0" bgcolor="#292929">
    <tr>
        <td>
            <table border="0" width ="100%" height="auto" cellpadding="" cellspacing ="0" align="center">
                <tr>
                    <td align="center" valign="middle" >
                        <h1>
                            <font align="left" face ="arial" color="#f3971b" size="7">
                            কঠোর লকডাউন
                            </font>
                        </h1>
                        <h3>
                            <marquee behavior="alternate" direction="left" scrollamount="6">
                                <font face ="arial" color="#ba4c4a" size="">
                                করোনাভাইরাসের সংক্রমণ পরিস্থিতি উদ্বেগজনক পর্যায়ে পৌঁছে যাওয়ায় 
                                বিশেষজ্ঞদের সুপারিশে সোমবার থেকে পরবর্তী নির্দেশ না দেওয়া 
                                পর্যনত সারাদেশে ‘কঠোর লকডাউন’ জারির ঘোষণা দিয়েছে সরকার।
                                </font>
                            </marquee>
                        </h3>
                        <h5>
                        <font face="arial" color="#ffffff" size="3">
                       এই সময়ে জরুরি প্রয়োজন ছাড়া কেউ বাড়ির বাইরে বের হতে পারবেন না। 
                       জরুরি পরিষেবা ছাড়া সকল সরকারি বেসরকারি অফিস বন্ধ থাকবে।

                        জরুরি পণ্যবাহী পরিবহন ছাড়া সব ধরনের যানবাহন চলাচল বন্ধ থাকবে।
                        তবে অ্যাম্বুলেন্স ও চিকৎসা সংক্রান্ত কাজে ব্যবহৃত যানবাহন এবং গণমাধ্যম 
                        নিষেধাজ্ঞার বাইরে থাকবে।

                        শনিবার মন্ত্রিপরিষদ বিভাগ থেকে বিধিনিষেধের বিষয়ে বিস্তারিত আদেশ জারি
                        করা হবে বলে প্রধান তথ্য কর্মকর্তা সুরথ কুমার সরকার এক বার্তায় জানিয়েছেন।

                        মহামারীর দ্বিতীয় ঢেউ শুরুর পর গত এপ্রিলের মাঝামাঝি থেকেই সারাদেশে ধাপে ধাপে 
                        মেয়াদ বাড়িয়ে লকডাউনের বিধিনিষেধ চালু রাখা হয়েছে। তবে সময় গড়ানোর সঙ্গে সঙ্গে
                         শিথিল করা হয়েছে বেশ কিছু নিয়ম।

                        এর মধ্যে করোনাভাইরাসের অতিসংক্রামক ডেল্টা ভ্যারিয়েন্ট ছড়িয়ে পড়ায় জুনের শুরু থেকে
                         সংক্রমণ ও মৃত্যু বাড়তে বাড়তে উদ্বেগজনক পর্যায়ে পৌঁছেছে।

                        </font>
                        </h5>
                        
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<!-- End Home -->

    </body>
</html>